#!/usr/bin/env python3
"""Baixa dados do SAPL da Câmara de Monte Mor e gera dados.json no formato do painel.
Uso:  pip install requests  &&  python sapl_para_painel.py
Depois cole o conteúdo de dados.json na aba "Dados" do painel e clique em Carregar.
NOTA: baseado na API padrão do SAPL (/api/...). Não pude testar contra o servidor
de Monte Mor; se algum endpoint der erro, o script avisa e segue em frente.
"""
import json, requests

BASE = "https://sapl.montemor.sp.leg.br"
ANO = 2026  # ano a consultar

def pegar(caminho, **params):
    """Percorre todas as páginas de um endpoint da API."""
    url, itens = f"{BASE}/api/{caminho}/", []
    params.setdefault("page_size", 100)
    while url:
        try:
            r = requests.get(url, params=params, timeout=30)
            r.raise_for_status()
        except Exception as e:
            print(f"  ! falha em {caminho}: {e}")
            return itens
        j = r.json()
        itens += j.get("results", [])
        url, params = j.get("pagination", {}).get("links", {}).get("next"), {}
    print(f"  {caminho}: {len(itens)} registros")
    return itens

nome = lambda x: x.get("__str__") or str(x.get("id"))
print("Baixando…")

parl = pegar("parlamentares/parlamentar")
ativos = [p for p in parl if p.get("ativo", True)]
sess = [s for s in pegar("sessao/sessaoplenaria", data_inicio__year=ANO)]
ids_sess = {s["id"] for s in sess}
pres = pegar("sessao/sessaoplenariapresenca")
ordem = pegar("sessao/ordemdia")
mats = {m["id"]: m for m in pegar("materia/materialegislativa", ano=ANO)}
regs = pegar("sessao/registrovotacao")
votos = pegar("sessao/votoparlamentar")

vereadores = [{"id": p["id"], "nome": p.get("nome_parlamentar") or nome(p),
               "partido": p.get("partido", "") if isinstance(p.get("partido", ""), str) else ""} for p in ativos]
todos = {v["id"] for v in vereadores}

presentes = {}
for x in pres:
    presentes.setdefault(x["sessao_plenaria"], set()).add(x["parlamentar"])

pauta = {}
for o in ordem:
    if o.get("sessao_plenaria") in ids_sess:
        pauta.setdefault(o["sessao_plenaria"], []).append(o["materia"])

sessoes = []
for s in sorted(sess, key=lambda s: s["data_inicio"], reverse=True):
    sessoes.append({"id": s["id"], "data": s["data_inicio"][:10],
                    "tipo": str(s.get("tipo") if not isinstance(s.get("tipo"), dict) else s["tipo"].get("nome", "")) or "Sessão",
                    "pauta": pauta.get(s["id"], []),
                    "ausentes": sorted(todos - presentes.get(s["id"], set())) if s["id"] in presentes else [],
                    "justificados": []})  # justificativas: ver /api/sessao/justificativaausencia, se existir

projetos = [{"id": i, "numero": nome(m), "autor": "—", "ementa": m.get("ementa", ""), "status": "Em tramitação"}
            for i, m in mats.items()]

# Votos agrupados por registro de votação
por_reg = {}
for v in votos:
    chave = v.get("object_id") or v.get("votacao")
    voto = (v.get("voto") or "").lower()
    por_reg.setdefault(chave, {})[v["parlamentar"]] = "S" if voto.startswith("sim") else "N" if voto.startswith("n") else "A"

ordem_por_id = {o["id"]: o for o in ordem}
votacoes = []
for r in regs:
    o = ordem_por_id.get(r.get("ordem"))
    if not o or r["id"] not in por_reg:
        continue
    votacoes.append({"projeto": o["materia"], "sessao": o["sessao_plenaria"], "votos": por_reg[r["id"]]})
    res = str(r.get("tipo_resultado_votacao", ""))
    for p in projetos:
        if p["id"] == o["materia"]:
            p["status"] = "Aprovado" if "aprov" in res.lower() else "Rejeitado" if "rejei" in res.lower() else p["status"]

json.dump({"vereadores": vereadores, "sessoes": sessoes, "projetos": projetos, "votacoes": votacoes},
          open("dados.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print("Pronto: dados.json gerado.")
